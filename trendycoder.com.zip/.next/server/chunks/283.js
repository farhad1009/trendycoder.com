"use strict";
exports.id = 283;
exports.ids = [283];
exports.modules = {

/***/ 4283:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout3)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Layout/Footer3.js




function Footer3({
  className
}) {
  // console.log(className);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
    className: "footer__area footer-bg-3 pt-120 p-relative fix",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "footer__shape",
      children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
        className: "footer-circle-1 footer-2-circle-1",
        src: "/img/icon/footer/home-1/circle-1.png",
        alt: ""
      }), /*#__PURE__*/jsx_runtime_.jsx("img", {
        className: "footer-circle-2 footer-2-circle-2",
        src: "/img/icon/footer/home-1/circle-2.png",
        alt: ""
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "footer__top pb-65",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "container",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "row",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-xxl-3 col-xl-3 col-lg-3 col-md-4 col-sm-6 wow fadeInUp",
            "data-wow-delay": ".3s",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "footer__widget mb-50",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "footer__widget-title mb-25",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "footer__logo",
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "#",
                    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                      children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                        src: "/img/logo/logo-2.png",
                        alt: "logo"
                      })
                    })
                  })
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "footer__widget-content footer__widget-content-3",
                children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                  children: "We are a developer team. We are also available in Themeforest."
                })
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-xxl-2 col-xl-2 col-lg-2 col-md-4 col-sm-6 wow fadeInUp",
            "data-wow-delay": ".5s",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "footer__widget mb-50 footer__pl-70",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "footer__widget-title footer__widget-title-3 mb-25",
                children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  children: "Overview"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "footer__widget-content",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "footer__link footer__link-3",
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
                    children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: "Terms"
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: "Privacy Policy"
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: "Cookies"
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: "Integrations"
                        })
                      })
                    })]
                  })
                })
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-xxl-3 col-xl-2 col-lg-2 col-md-4 col-sm-6 wow fadeInUp",
            "data-wow-delay": ".7s",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "footer__widget mb-50 footer__pl-90",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "footer__widget-title footer__widget-title-3 mb-25",
                children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  children: "Customer"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "footer__widget-content",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "footer__link footer__link-3",
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
                    children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: "Home"
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: "Product"
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: "Pricing"
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: "Integrations"
                        })
                      })
                    })]
                  })
                })
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-xxl-2 col-xl-2 col-lg-2 col-md-4 col-sm-6 wow fadeInUp",
            "data-wow-delay": ".9s",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "footer__widget mb-50",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "footer__widget-title footer__widget-title-3 mb-25",
                children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  children: "Product"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "footer__widget-content",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "footer__link footer__link-3",
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
                    children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: "Getting Started"
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: "Style Guide"
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: "Licences"
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: "Changelog"
                        })
                      })
                    })]
                  })
                })
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-xxl-2 col-xl-3 col-lg-3 col-md-4 col-sm-6 wow fadeInUp",
            "data-wow-delay": "1.2s",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "footer__widget mb-50 float-md-end fix",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "footer__widget-title footer__widget-title-3 mb-25",
                children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  children: "Follow Us"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "footer__widget-content",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "footer__social footer__social-3",
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
                    children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                            className: "fab fa-facebook-f"
                          })
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                            className: "fab fa-twitter"
                          })
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                            className: "fab fa-pinterest-p"
                          })
                        })
                      })
                    })]
                  })
                })
              })]
            })
          })]
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "footer__bottom",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "container",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "footer__copyright footer__copyright-2",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "row",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "col-xxl-12 wow fadeInUp",
              "data-wow-delay": "1.5s",
              children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "footer__copyright-wrapper footer__copyright-wrapper-3 text-center",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                  children: ["Copyright \xA9 2021 All Rights Reserved passion by ", /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "#",
                    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                      children: "TrendyCoder"
                    })
                  })]
                })
              })
            })
          })
        })
      })
    })]
  });
}
// EXTERNAL MODULE: ./components/Layout/NavBarMain.js
var NavBarMain = __webpack_require__(1346);
// EXTERNAL MODULE: ./components/Layout/NavBarMobile.js
var NavBarMobile = __webpack_require__(4817);
;// CONCATENATED MODULE: ./components/Layout/Header5.js








function Header5() {
  const {
    0: isToggled,
    1: setToggled
  } = (0,external_react_.useState)(false);

  const toggleTrueFalse = () => setToggled(!isToggled); // const [size, setSize] = useState(0);
  // console.log(size);


  const {
    0: scroll,
    1: setScroll
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    window.addEventListener("scroll", () => {
      setScroll(window.scrollY > 100);
    });
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: `progress-wrap ${scroll ? "active-progress" : ""}`
    }), /*#__PURE__*/jsx_runtime_.jsx("header", {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "header__area",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "header__top pt-5 pb-5 grey-bg-6",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "row",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-6",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "header__info text-center text-sm-start",
                  children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/mailto:trendycoder.com@gmail.com",
                    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                      children: [" ", /*#__PURE__*/jsx_runtime_.jsx("i", {
                        className: "icon_mail"
                      }), " trendycoder.com@gmail.com"]
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/tel:88 016 74 05 29 25",
                    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                      children: [" ", /*#__PURE__*/jsx_runtime_.jsx("i", {
                        className: "icon_phone w-phone"
                      }), " 88 016 74 05 29 25"]
                    })
                  })]
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-6",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "header__social fix float-end d-none d-sm-block",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("h5", {
                    children: "Follow us:"
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
                    children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                            className: "fab fa-pinterest-p"
                          })
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                            className: "fab fa-twitter"
                          })
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "https://www.facebook.com/farhadchowdhury1009/",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                            className: "fab fa-facebook-f"
                          })
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "https://www.linkedin.com/in/trendy-coder-020276218/",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                            className: "fab fa-linkedin-in"
                          })
                        })
                      })
                    })]
                  })]
                })
              })]
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          id: "header-sticky",
          className: `header__bottom header__padding ${scroll ? "sticky" : ""}`,
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "row align-items-center",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "col-xxl-2 col-xl-2 col-lg-2 col-md-6 col-6",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "logo",
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/",
                    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                      children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                        src: "/img/logo/logo.png",
                        alt: "logo"
                      })
                    })
                  })
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "col-xxl-8 col-xl-7 col-lg-7 d-none d-lg-block",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "main-menu main-menu-5 ml-90",
                  children: /*#__PURE__*/jsx_runtime_.jsx(NavBarMain/* default */.Z, {})
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "col-xxl-2 col-xl-3 col-lg-3 col-md-6 col-6",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "header__action d-flex align-items-center justify-content-end",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "header__search",
                    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                      href: "/javascript:void(0);",
                      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                        className: "searchOpen",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "far fa-search"
                        })
                      })
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "header__right-btn d-none d-md-flex d-xl-block ml-30",
                    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                      href: "/contact",
                      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                        className: "w-btn w-btn-11 mt-5",
                        children: "Get a quote"
                      })
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "sidebar__menu d-flex justify-content-end d-lg-none",
                    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      onClick: setToggled,
                      className: "sidebar-toggle-btn sidebar-toggle-btn-5",
                      id: "sidebar-toggle",
                      children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                        className: "line"
                      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                        className: "line"
                      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                        className: "line"
                      })]
                    })
                  })]
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: `sidebar__area ${!isToggled ? "" : "sidebar-opened"}`,
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "sidebar__wrapper",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "sidebar__close",
                    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
                      onClick: toggleTrueFalse,
                      className: "sidebar__close-btn",
                      id: "sidebar__close-btn",
                      children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fal fa-times"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                        children: "close"
                      })]
                    })
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "sidebar__content",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: "logo mb-40",
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "/",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                            src: "/img/logo/logo.png",
                            alt: "logo"
                          })
                        })
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: `mobile-menu mean-container`,
                      children: /*#__PURE__*/jsx_runtime_.jsx(NavBarMobile/* default */.Z, {})
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "sidebar__info mt-350",
                      children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          className: "w-btn w-btn-4 d-block mb-15 mt-15",
                          children: "login"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                        href: "#",
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          className: "w-btn d-block",
                          children: "sign up"
                        })
                      })]
                    })]
                  })]
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: `body-overlay ${!isToggled ? "" : "opened"}`
              })]
            })
          })
        })]
      })
    })]
  });
}
// EXTERNAL MODULE: ./components/Layout/Sidebar.js
var Sidebar = __webpack_require__(8933);
;// CONCATENATED MODULE: ./components/Layout/Layout5.js







function Layout3({
  children,
  className
}) {
  // console.log(className);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Header5, {}), /*#__PURE__*/jsx_runtime_.jsx(Sidebar/* default */.Z, {}), children, /*#__PURE__*/jsx_runtime_.jsx(Footer3, {
      className: className
    })]
  });
}

/***/ })

};
;